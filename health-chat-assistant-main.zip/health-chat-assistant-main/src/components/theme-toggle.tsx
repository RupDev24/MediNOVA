
// This component is no longer used since we're always in dark mode
export function ThemeToggle() {
  return null;
}
